class ProfileCtrl {
  constructor() {
    'ngInject';

  }
}


export default ProfileCtrl;
