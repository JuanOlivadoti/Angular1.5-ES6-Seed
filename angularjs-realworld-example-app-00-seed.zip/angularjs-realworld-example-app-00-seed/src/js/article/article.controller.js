class ArticleCtrl {
  constructor() {
    'ngInject';

  }
}


export default ArticleCtrl;
