import angular from 'angular';

let componentsModule = angular.module('app.components', []);


export default componentsModule;
